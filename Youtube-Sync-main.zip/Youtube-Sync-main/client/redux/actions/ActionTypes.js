export const INIT_SOCKET = "INIT_SOCKET"
export const SET_USERS = "SET_USERS"
export const SET_USERNAME = "SET_USERNAME"
export const SET_VIDEO_ID = "SET_VIDEO_ID"
